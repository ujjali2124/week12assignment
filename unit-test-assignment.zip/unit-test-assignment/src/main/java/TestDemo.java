import java.lang.*;
import java.util.Random;

public class TestDemo {
	public static int addPositive(int a, int b) {
		if ( a > 0 && b > 0) {
			return a+b;
		}
		else {
			throw new IllegalArgumentException("Both parameters must be positive!");
		}
	}

	public int getRandomInt() {
		// TODO Auto-generated method stub
		Random random = new Random();
		return random.nextInt(10) + 1;
	}

	public int randomNumberSquared() {
		// TODO Auto-generated method stub
		
		int randomInt = getRandomInt();
		return randomInt * randomInt;
	}

}
